#!/usr/bin/env python
# coding: utf-8

# In[15]:


import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


# In[13]:


df= pd.read_csv(r"C:\Users\Gourvit\OneDrive\Desktop\Imarticus DS\Project finals\Python_Diwali_Sales_Analysis\Python_Diwali_Sales_Analysis\Diwali Sales Data.csv", encoding= 'unicode_escape')


# In[14]:


df.head()


# In[17]:


df.drop(['Status', 'unnamed1'], axis=1, inplace=True)


# In[19]:


df.dtypes


# In[20]:


df.isnull().sum()


# In[23]:


df.dropna(inplace=True)


# In[24]:


df['Amount'] = df['Amount'].astype('int')


# In[25]:


df.describe()


# ## Graphs

# In[26]:


ax = sns.countplot(x = 'Gender',data = df)

for bars in ax.containers:
    ax.bar_label(bars)


# In[28]:


sales_gen = df.groupby(['Gender'], as_index=False)['Amount'].sum().sort_values(by='Amount', ascending=False)

sns.barplot(x = 'Gender',y= 'Amount' ,data = sales_gen)


# In[29]:


ax = sns.countplot(data = df, x = 'Age Group', hue = 'Gender')

for bars in ax.containers:
    ax.bar_label(bars)


# In[31]:


sales_age = df.groupby(['Age Group'], as_index=False)['Amount'].sum().sort_values(by='Amount', ascending=False) 
sales_age


# In[33]:


sns.barplot(x= 'Age Group', y='Amount', data=sales_age)


# In[34]:


df.columns


# In[41]:


sales_state = df.groupby(['State'], as_index=False)['Orders'].sum().sort_values(by='Orders', ascending=False)


# In[42]:


sales_state


# In[50]:


sns.barplot(data=sales_state,x='State', y='Orders')


# In[53]:


sales_state1 = df.groupby(['State'], as_index=False)['Amount'].sum().sort_values(by='Amount', ascending=False).head(10)


# In[54]:


sns.barplot(x='State', y='Amount', data=sales_state1)


# In[59]:


mx= sns.countplot(data=df, x="Marital_Status")
for bars in mx.containers:
    mx.bar_label(bars)


# In[60]:


sales_state = df.groupby(['Gender', 'Marital_Status'], as_index=False)['Amount'].sum().sort_values(by='Amount', ascending=False)


# In[62]:


sns.barplot(data=sales_state, x='Marital_Status', y='Amount', hue='Gender')


# In[63]:


sns.set(rc={'figure.figsize':(20,5)})
ax = sns.countplot(data = df, x = 'Occupation')

for bars in ax.containers:
    ax.bar_label(bars)


# In[64]:


sales_state = df.groupby(['Occupation'], as_index=False)['Amount'].sum().sort_values(by='Amount', ascending=False)

sns.set(rc={'figure.figsize':(20,5)})
sns.barplot(data = sales_state, x = 'Occupation',y= 'Amount')


# In[65]:


sns.set(rc={'figure.figsize':(20,5)})
ax = sns.countplot(data = df, x = 'Product_Category')

for bars in ax.containers:
    ax.bar_label(bars)


# In[66]:


sales_state = df.groupby(['Product_Category'], as_index=False)['Amount'].sum().sort_values(by='Amount', ascending=False).head(10)

sns.set(rc={'figure.figsize':(20,5)})
sns.barplot(data = sales_state, x = 'Product_Category',y= 'Amount')


# In[67]:


sales_state = df.groupby(['Product_ID'], as_index=False)['Orders'].sum().sort_values(by='Orders', ascending=False).head(10)

sns.set(rc={'figure.figsize':(20,5)})
sns.barplot(data = sales_state, x = 'Product_ID',y= 'Orders')


# In[68]:


# top 10 most sold products (same thing as above)

fig1, ax1 = plt.subplots(figsize=(12,7))
df.groupby('Product_ID')['Orders'].sum().nlargest(10).sort_values(ascending=False).plot(kind='bar')


# In[ ]:




